<!DOCTYPE html>
<html lang="en">
<head>
  <link href="/assets/css/tailwind.css" rel="stylesheet">
  <title>Register</title>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
  <form method="post" class="bg-white p-6 rounded shadow w-1/3">
    <h2 class="text-2xl mb-4 font-bold">Register</h2>
    <input type="text" name="username" placeholder="Username" required class="w-full mb-3 p-2 border" />
    <input type="email" name="email" placeholder="Email" required class="w-full mb-3 p-2 border" />
    <input type="password" name="password" placeholder="Password" required class="w-full mb-3 p-2 border" />
    <button class="bg-green-500 text-white px-4 py-2 rounded">Register</button>
  </form>
</body>
</html>
