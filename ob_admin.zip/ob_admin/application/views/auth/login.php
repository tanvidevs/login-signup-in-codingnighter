<!DOCTYPE html>
<html lang="en">
<head>
  <link href="/assets/css/tailwind.css" rel="stylesheet">
  <title>Login</title>
</head>
<body class="bg-gray-100 flex items-center justify-center h-screen">
  <form method="post" class="bg-white p-6 rounded shadow w-1/3">
    <h2 class="text-2xl mb-4 font-bold">Login</h2>
    <input type="email" name="email" placeholder="Email" required class="w-full mb-3 p-2 border" />
    <input type="password" name="password" placeholder="Password" required class="w-full mb-3 p-2 border" />
    <button class="bg-blue-500 text-white px-4 py-2 rounded">Login</button>

	<p class="mt-4 text-center text-sm">
      Don’t have an account?
	  <a href="<?= site_url('register') ?>" class="text-blue-500 hover:underline">

        Sign up here
      </a>
    </p>
  </form>
</body>
</html>
