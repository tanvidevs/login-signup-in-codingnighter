<!DOCTYPE html>
<html lang="en">
<head>
  <link href="/assets/css/tailwind.css" rel="stylesheet">
  <title>Dashboard</title>
</head>
<body class="bg-gray-100 text-center p-10">
  <h1 class="text-3xl font-bold">Welcome, <?= $user->username ?>!</h1>
  <p class="mt-4">You have successfully signed in.</p>
</body>
</html>
