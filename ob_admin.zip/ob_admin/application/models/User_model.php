<?php
class User_model extends CI_Model {

    public function email_exists($email) {
        return $this->db->get_where('users', ['email' => $email])->num_rows() > 0;
    }

    public function register($data) {
        if ($this->email_exists($data['email'])) {
            return false; // Email already taken
        }
        return $this->db->insert('users', $data);
    }

    public function login($email, $password) {
        $query = $this->db->get_where('users', ['email' => $email]);
        $user = $query->row();

        if ($user && password_verify($password, $user->password)) {
            return $user;
        }
        return false;
    }

    public function get_all_users() {
        return $this->db->get('users')->result();
    }

    public function update_user($id, $data) {
        return $this->db->update('users', $data, ['id' => $id]);
    }

    public function delete_user($id) {
        return $this->db->delete('users', ['id' => $id]);
    }
}
