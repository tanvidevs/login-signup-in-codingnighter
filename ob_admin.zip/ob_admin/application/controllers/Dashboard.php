<?php
class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');  // ✅ This is the fix
        $this->load->library('session'); // Also ensure session library is loaded
    }

    public function index() {
        $user = $this->session->userdata('user');
        if (!$user) redirect('login');
        $this->load->view('dashboard', ['user' => $user]);
    }
}
