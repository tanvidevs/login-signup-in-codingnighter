<?php
class Api extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->database(); 
    }

    public function index() {
        header('Content-Type: application/json');
        $users = $this->User_model->get_all_users();

        if (!empty($users)) {
            echo json_encode(['status' => 'success', 'data' => $users]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No users found']);
        }
    }

    public function create() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents("php://input"), true);
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        $this->User_model->register($data);
        echo json_encode(['status' => 'success', 'message' => 'User created']);
    }

    public function update($id) {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents("php://input"), true);
        $this->User_model->update_user($id, $data);
        echo json_encode(['status' => 'success', 'message' => 'User updated']);
    }

    public function delete($id) {
        header('Content-Type: application/json');
        $this->User_model->delete_user($id);
        echo json_encode(['status' => 'success', 'message' => 'User deleted']);
    }
}
