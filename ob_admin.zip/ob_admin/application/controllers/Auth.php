<?php
class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');  // ✅ Load URL helper
		$this->load->database();  // ✅ Load the database
		$this->load->library('session');  // ✅ Add this line
    }

    public function index() {
        // By default show login page.
        redirect('login'); 
    }

    public function register() {
        if ($_POST) {
            $this->load->model('User_model');
            $data = [
                'username' => $this->input->post('username'),
                'email' => $this->input->post('email'),
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
            ];
            $this->User_model->register($data);
            redirect('login');
        }
        $this->load->view('auth/register');
    }

    public function login() {
        if ($_POST) {
            $this->load->model('User_model');
            $user = $this->User_model->login($this->input->post('email'), $this->input->post('password'));
            if ($user) {
                $this->session->set_userdata('user', $user);
                redirect('dashboard');
            } else {
                echo "Invalid login";
            }
        }
        $this->load->view('auth/login');
    }
}
